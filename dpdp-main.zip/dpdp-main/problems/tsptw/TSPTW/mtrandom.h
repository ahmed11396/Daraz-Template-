#ifndef MTRANDOM_
#define MTRANDOM_

void init_genrand(unsigned long s);
unsigned long genrand_int32(void);

#endif

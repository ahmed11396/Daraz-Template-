#ifndef INCLUDES_
#define INCLUDES_
//------------------------------------------------------------------------------
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>
#include <time.h>
#include <ctime>
#include <algorithm> 
#include <math.h> 
#include <errno.h>
#include <dirent.h>
#include <sys/types.h>
#include <iomanip>
//------------------------------------------------------------------------------
#include "mtrandom.h"
//------------------------------------------------------------------------------
using namespace std;
//------------------------------------------------------------------------------
#endif

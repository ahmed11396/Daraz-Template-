# TSPTW
The Traveling Salesman Problem with Time Windows (TSPTW)

[Reference] 
da Silva, R. F., Urrutia, S. [2010] A General VNS heuristic for the traveling salesman problem with time windows, Discrete Optimization, Volume 7, Issue 4, November 2010, Pages 203-211, ISSN 1572-5286, DOI: 10.1016/j.disopt.2010.04.002.

I have found this code published at http://homepages.dcc.ufmg.br/~rfsilva/tsptw/
(together with large amount of benchmarks and other useful info), added Makefile and some minor adoptioption.

To build it type ```make```. To run - get benchmark set(s) from above.

Happy hacking!
